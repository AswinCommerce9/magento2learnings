<?php
namespace Com9\ConsoleModule\Console;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Saymyname extends Command
{
   protected function configure()
   {
       $this->setName('example:sayname');
       $this->setDescription('Demo command line');
       
       parent::configure();
   }
   protected function execute(InputInterface $input, OutputInterface $output)
   {
       $output->writeln("Ashmitha");
   }
}
