<?php

namespace Com9\ConsoleModule\Console;

use Magento\Backend\Block\Template\Context;
use Magento\Framework\App\State;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputOption;



class Enableproduct extends Command
{

    const NAME = 'name';

    protected $_productCollectionFactory;
    protected $appState;

    public function __construct(
        Context $context, CollectionFactory $productCollectionFactory,State $appState,array $data = []
        ) {
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->appState = $appState;
        parent::__construct($context, $data);
    }


    protected function configure()
    {

        $options = [
            new InputOption(
                self::NAME,
                null,
                InputOption::VALUE_REQUIRED,
                'Name'
            )
        ];

        $this->setName('p:productenable')
            ->setDescription('Enable Product')
            ->setDefinition($options);

        parent::configure();
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $collection = $this->_productCollectionFactory->create();
        foreach ($collection as $data) {

            $output->writeln($data->getId());
            $output->writeln("Product enabled successfully");
            $this->appState->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);
        }

    }

}

?>
